<?php
    header("Location:wallet");
?>